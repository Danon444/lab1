#pragma once

char *program(int argc, char *argv[]);
